This directory contains files which are automatically generated.
Don't modify them directly.